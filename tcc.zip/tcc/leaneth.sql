-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 21-Nov-2018 às 17:35
-- Versão do servidor: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leaneth`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administrador`
--

CREATE TABLE `administrador` (
  `razao_social` varchar(150) NOT NULL,
  `cnpj` varchar(150) NOT NULL,
  `id_usuarios` int(11) NOT NULL,
  `idAdministrador` int(11) NOT NULL,
  `nome_fantasia` varchar(150) NOT NULL,
  `ativado` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `administrador`
--

INSERT INTO `administrador` (`razao_social`, `cnpj`, `id_usuarios`, `idAdministrador`, `nome_fantasia`, `ativado`) VALUES
('admin', 'admin', 53, 25, 'admin', 0),
('administrador', 'administrador', 54, 26, 'administrador', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente_loja`
--

CREATE TABLE `cliente_loja` (
  `nomeFantasia` varchar(150) DEFAULT NULL,
  `cnpj` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `razao_social` varchar(150) DEFAULT NULL,
  `telefone` varchar(150) DEFAULT NULL,
  `idCliente` int(11) NOT NULL,
  `endereco` varchar(150) NOT NULL,
  `vendedor_idVendedor` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cliente_loja`
--

INSERT INTO `cliente_loja` (`nomeFantasia`, `cnpj`, `email`, `razao_social`, `telefone`, `idCliente`, `endereco`, `vendedor_idVendedor`, `ativado`) VALUES
('1117', '1117', '1117@teste', '1117', '1117', 6, '1117', 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cor`
--

CREATE TABLE `cor` (
  `id_cor` int(11) NOT NULL,
  `cor` varchar(145) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `cor`
--

INSERT INTO `cor` (`id_cor`, `cor`, `ativado`) VALUES
(40, 'Amarelo\r\n', 0),
(41, 'Verde', 0),
(42, 'ROXO\r\n', 0),
(43, 'VEERDE', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `historico`
--

CREATE TABLE `historico` (
  `idhistorico` int(11) NOT NULL,
  `produtos_idProdutos` int(11) NOT NULL,
  `qtd` varchar(45) DEFAULT NULL,
  `cliente_loja_idCliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem`
--

CREATE TABLE `imagem` (
  `id_imagem` int(11) NOT NULL,
  `imagem` varchar(64) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `imagem`
--

INSERT INTO `imagem` (`id_imagem`, `imagem`, `ativado`) VALUES
(24, '270918021904cana de acucar.jpg', 0),
(25, '171018081019', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `idProdutos` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `preco` varchar(150) DEFAULT NULL,
  `estoque` int(11) DEFAULT NULL,
  `estoque_min` int(11) DEFAULT NULL,
  `descricao` varchar(150) DEFAULT NULL,
  `referencia` int(15) NOT NULL,
  `idTipoProduto` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`idProdutos`, `nome`, `preco`, `estoque`, `estoque_min`, `descricao`, `referencia`, `idTipoProduto`, `ativado`) VALUES
(41, 'TESTE', '456', 65, 65, 'teste', 1212, 1, 0),
(42, 'tseste', '5765', 64, 8, 'ghtgdfj', 656789, 3, 0),
(44, 'TESTE', '456', 65, 65, 'teste', 1212, 1, 0),
(45, 'TESTE', '456', 65, 65, 'teste', 1212, 1, 0),
(46, 'TESTE', '200.00', 123, 45, 'teste de cadastro', 1212, 3, 0),
(47, '1054', '373', 23, 2333, 'teste de cadastro', 1212, 3, 0),
(48, '1118', '200.00', 34, 63, '', 547654, 3, 0),
(49, 'blusa com decote canoa', '50', 65, 45, 'Uma blusa bÃ¡sica com um decote levemente canoado para a esquerda ', 547654, 3, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prod_cor`
--

CREATE TABLE `prod_cor` (
  `prod_id_prod` int(11) NOT NULL,
  `cor_id_cor` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prod_cor`
--

INSERT INTO `prod_cor` (`prod_id_prod`, `cor_id_cor`, `ativado`) VALUES
(46, 40, 0),
(47, 41, 0),
(48, 42, 0),
(49, 43, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prod_imagem`
--

CREATE TABLE `prod_imagem` (
  `prod_id_prod` int(11) NOT NULL,
  `img_id_img` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prod_imagem`
--

INSERT INTO `prod_imagem` (`prod_id_prod`, `img_id_img`, `ativado`) VALUES
(48, 24, 0),
(49, 25, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `prod_tamanho`
--

CREATE TABLE `prod_tamanho` (
  `tam_id_tam` int(11) NOT NULL,
  `prod_id_prod` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prod_tamanho`
--

INSERT INTO `prod_tamanho` (`tam_id_tam`, `prod_id_prod`, `ativado`) VALUES
(34, 46, 0),
(37, 47, 0),
(37, 49, 0),
(38, 48, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tamanho`
--

CREATE TABLE `tamanho` (
  `tamanho` varchar(5) DEFAULT NULL,
  `idTamanho` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tamanho`
--

INSERT INTO `tamanho` (`tamanho`, `idTamanho`, `ativado`) VALUES
('0', 34, 0),
('0', 35, 0),
('0', 36, 0),
('34', 37, 0),
('37', 38, 0),
('38', 39, 0),
('37', 40, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_produto`
--

CREATE TABLE `tipo_produto` (
  `tipo` varchar(150) DEFAULT NULL,
  `idTipoProduto` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tipo_produto`
--

INSERT INTO `tipo_produto` (`tipo`, `idTipoProduto`) VALUES
('Calça', 1),
('Shorts', 2),
('Blusa', 3),
('Casaco', 4);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `telefone` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `senha` varchar(150) DEFAULT NULL,
  `nome` varchar(150) DEFAULT NULL,
  `idUsuarios` int(11) NOT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`telefone`, `email`, `senha`, `nome`, `idUsuarios`, `ativado`) VALUES
('admin', 'admin', 'admin', 'admin', 53, 0),
('administrador', 'administrador', '123', 'administrador', 54, 0),
('vend', 'vend', 'vend', 'vend', 55, 0),
('vendedor', 'vendedor', '123', 'vendedor', 56, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `vendedor`
--

CREATE TABLE `vendedor` (
  `idVendedor` int(11) NOT NULL,
  `cpf` varchar(150) DEFAULT NULL,
  `id_usuarios` int(11) DEFAULT NULL,
  `empresa` varchar(105) DEFAULT NULL,
  `ativado` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `vendedor`
--

INSERT INTO `vendedor` (`idVendedor`, `cpf`, `id_usuarios`, `empresa`, `ativado`) VALUES
(17, 'vend', 55, 'vend', 1),
(18, 'vendedor', 56, 'vendedor', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`idAdministrador`),
  ADD KEY `idUsuarios` (`id_usuarios`);

--
-- Indexes for table `cliente_loja`
--
ALTER TABLE `cliente_loja`
  ADD PRIMARY KEY (`idCliente`),
  ADD KEY `fk_cliente_loja_vendedor1_idx` (`vendedor_idVendedor`);

--
-- Indexes for table `cor`
--
ALTER TABLE `cor`
  ADD PRIMARY KEY (`id_cor`);

--
-- Indexes for table `historico`
--
ALTER TABLE `historico`
  ADD PRIMARY KEY (`idhistorico`),
  ADD KEY `fk_historico_produtos1_idx` (`produtos_idProdutos`),
  ADD KEY `fk_historico_cliente_loja1_idx` (`cliente_loja_idCliente`);

--
-- Indexes for table `imagem`
--
ALTER TABLE `imagem`
  ADD PRIMARY KEY (`id_imagem`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`idProdutos`),
  ADD KEY `idTipoProduto` (`idTipoProduto`);

--
-- Indexes for table `prod_cor`
--
ALTER TABLE `prod_cor`
  ADD PRIMARY KEY (`prod_id_prod`,`cor_id_cor`),
  ADD KEY `fk_produtos_has_cor_cor1_idx` (`cor_id_cor`),
  ADD KEY `fk_produtos_has_cor_produtos1_idx` (`prod_id_prod`);

--
-- Indexes for table `prod_imagem`
--
ALTER TABLE `prod_imagem`
  ADD PRIMARY KEY (`prod_id_prod`,`img_id_img`),
  ADD KEY `fk_produtos_has_imagem_imagem1_idx` (`img_id_img`),
  ADD KEY `fk_produtos_has_imagem_produtos1_idx` (`prod_id_prod`);

--
-- Indexes for table `prod_tamanho`
--
ALTER TABLE `prod_tamanho`
  ADD PRIMARY KEY (`tam_id_tam`,`prod_id_prod`),
  ADD KEY `fk_tamanho_has_produtos_produtos1_idx` (`prod_id_prod`),
  ADD KEY `fk_tamanho_has_produtos_tamanho1_idx` (`tam_id_tam`);

--
-- Indexes for table `tamanho`
--
ALTER TABLE `tamanho`
  ADD PRIMARY KEY (`idTamanho`);

--
-- Indexes for table `tipo_produto`
--
ALTER TABLE `tipo_produto`
  ADD PRIMARY KEY (`idTipoProduto`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuarios`);

--
-- Indexes for table `vendedor`
--
ALTER TABLE `vendedor`
  ADD PRIMARY KEY (`idVendedor`),
  ADD KEY `idUsuarios` (`id_usuarios`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrador`
--
ALTER TABLE `administrador`
  MODIFY `idAdministrador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `cliente_loja`
--
ALTER TABLE `cliente_loja`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `cor`
--
ALTER TABLE `cor`
  MODIFY `id_cor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `historico`
--
ALTER TABLE `historico`
  MODIFY `idhistorico` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `imagem`
--
ALTER TABLE `imagem`
  MODIFY `id_imagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `idProdutos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `tamanho`
--
ALTER TABLE `tamanho`
  MODIFY `idTamanho` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `tipo_produto`
--
ALTER TABLE `tipo_produto`
  MODIFY `idTipoProduto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuarios` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `vendedor`
--
ALTER TABLE `vendedor`
  MODIFY `idVendedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `administrador`
--
ALTER TABLE `administrador`
  ADD CONSTRAINT `administrador_ibfk_1` FOREIGN KEY (`id_usuarios`) REFERENCES `usuarios` (`idUsuarios`);

--
-- Limitadores para a tabela `historico`
--
ALTER TABLE `historico`
  ADD CONSTRAINT `fk_historico_cliente_loja1` FOREIGN KEY (`cliente_loja_idCliente`) REFERENCES `cliente_loja` (`idCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_historico_produtos1` FOREIGN KEY (`produtos_idProdutos`) REFERENCES `produtos` (`idProdutos`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`idTipoProduto`) REFERENCES `tipo_produto` (`idTipoProduto`);

--
-- Limitadores para a tabela `prod_cor`
--
ALTER TABLE `prod_cor`
  ADD CONSTRAINT `fk_produtos_has_cor_cor1` FOREIGN KEY (`cor_id_cor`) REFERENCES `cor` (`id_cor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_produtos_has_cor_produtos1` FOREIGN KEY (`prod_id_prod`) REFERENCES `produtos` (`idProdutos`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
