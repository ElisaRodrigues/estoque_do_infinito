<?php
require __DIR__.'/../crud/CrudVendedor.php';
require_once __DIR__. '/../models/Vendedor.php';

session_start();

function listarVendedores(){
    $crud = new CrudVendedor();
    $vendedores = $crud->getVendedores();
    include __DIR__."/../views/perfil_admin/visualizarvendedores.php";
}

function listarVend(){
    $vendedor = new CrudVendedor();



    $vend = $vendedor->getVendedor($_SESSION['id_user']);


    include __DIR__."/../views/perfil_vendedor/informacoesperfil.php";
}

function cadastrar(){
    $crud = new CrudVendedor();
    include __DIR__.'/../views/cadastro_vend.html';
}

function salvar(){ //DANDO ERRO
    $usuario = new Vendedor($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['telefone'], $_POST['cpf'],$_POST['empresa'], 1);
    $vend = new CrudVendedor();
    $resultado = $vend->cadastrar($usuario);

    header("Location: http://localhost/tcc/app/crud/login/login.php");
}

// este metodo é chamado pelo botao editar
// simplesmente carrega os dados do usuario e exibe o formulario para edita-los
function editar(){
    $crud = new CrudVendedor();
    $id_vendedor = $_SESSION['id_user'];
    $vend = $crud->getVendedor($id_vendedor);
    include '../views/perfil_vendedor/editar_vendedor.php';
}

function atualizar(){
    $crud = new CrudVendedor();
    $vend = new Vendedor($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['telefone'], $_POST['cpf'], $_POST['empresa'], 1,$_POST['idusu']);
    $crud->editar($vend);

    header("Location: http://localhost/tcc/app/controllers/vend_controller.php?acao=listarVend");
}

function excluirVend(){
    $crud = new CrudVendedor();
    $crud->excluir($_SESSION['id_user']);

    header("location: http://localhost/tcc/app/views/tela_inicio.php") ;
}

//ROTAS
if (isset($_GET['acao']) && !empty($_GET['acao']) ) {

    if ($_GET['acao'] == 'cadastrar') {
        cadastrar();

    } elseif ($_GET['acao'] == 'salvar') {
        salvar();

    } elseif ($_GET['acao'] == 'editar') {
        editar();

    } elseif ($_GET['acao'] == 'atualizar') {
        atualizar();

    }elseif ($_GET['acao'] == 'excluir') {
        excluirVend();

    }elseif ($_GET['acao'] == 'listarVendedores') {
        listarVendedores();

    } elseif ($_GET['acao'] == 'listarVend') {
        listarVend();
    }else {
        cadastrar();
    }
} else {
    cadastrar();
}