<?php
require_once __DIR__.'/../database/Conexao.php';
require_once __DIR__.'/../models/Vendedor.php';

class CrudVendedor{

    private $conexao;

    public function __construct(){
        $this->conexao = Conexao::getConexao();
    }

    public function cadastrar(Vendedor $usuario){

        $sql = "INSERT INTO usuarios (nome, email, senha, telefone, ativado) 
                VALUES ('{$usuario->getNome()}', '{$usuario->getEmail()}', '{$usuario->getSenha()}', '{$usuario->getTelefone()}', 1)";
        $this->conexao->exec($sql);

        $id = $this->conexao->lastInsertId(); //pega o ultimo id cadastrado

        $sq = "INSERT INTO vendedor (cpf, empresa, ativado, id_usuarios) 
               VALUES ('{$usuario->cpf}', '{$usuario->empresa}', 1, {$id})";
        $this->conexao->exec($sq);
    }

    public function getVendedores(){
        $sql = "select * from vendedor WHERE ativado == 1";
        $vendedores = $this->conexao->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        return $vendedores;
    }

    public function getVendedor($id_vend){
        $sql = "SELECT usuarios.idUsuarios, usuarios.nome,email,senha,telefone, vendedor.cpf,empresa
                FROM vendedor INNER JOIN usuarios ON usuarios.idUsuarios = vendedor.id_usuarios
                WHERE vendedor.idVendedor = $id_vend";

        $sql1 = "SELECT idUsuarios, nome, email, senha, telefone, cpf, empresa, idVendedor 
                 FROM usuarios, vendedor 
                 WHERE idUsuarios = id_usuarios 
                 AND idVendedor = $id_vend ";

        $vendedor = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);

        return new Vendedor($vendedor['nome'], $vendedor['email'], $vendedor['senha'], $vendedor['telefone'], $vendedor['cpf'], $vendedor['empresa'], 1, $vendedor['idUsuarios']);
    }

    public function excluir($id_usuario){
        //JUJU FZD
    }

    public function  editar (Vendedor $vend){
        $this->conexao->exec("UPDATE vendedor SET cpf = '{$vend->cpf}', empresa = '{$vend->empresa}' 
            WHERE id_usuarios = {$vend->getIdUsuario()}");

        $this->conexao->exec("UPDATE usuarios SET nome = '{$vend->getNome()}', 
                                                                 email = '{$vend->getEmail()}', 
                                                                  senha = {$vend->getSenha()}, 
                                                                  telefone = {$vend->getTelefone()}
            WHERE idUsuarios = {$vend->getIdUsuario()}");
    }
}